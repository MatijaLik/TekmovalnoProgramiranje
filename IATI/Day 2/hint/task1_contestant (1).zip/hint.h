#include <vector>

std::vector<bool> genHint(const std::vector<int>& a, const std::vector<int>& b, const std::vector<int>& sol);
std::vector<int> solve(const std::vector<int>& a, const std::vector<int>& b, const std::vector<bool>& hint);
