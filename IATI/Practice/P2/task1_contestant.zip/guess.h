#ifndef GUESS_H__
#define GUESS_H__

#ifdef __cplusplus
extern "C" {
#endif  // __cplusplus
    int quest(long long n);
    void res(long long answer);
    void guess();	
#ifdef __cplusplus
}
#endif  // __cplusplus

#endif  // GUESS_H__
