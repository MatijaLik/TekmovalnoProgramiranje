#include <vector>

long long find_maximum(int k, std::vector<std::vector<int>> d);
void allocate_tickets( std::vector<std::vector<int>> _x);
